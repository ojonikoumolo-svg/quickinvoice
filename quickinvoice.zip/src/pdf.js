/**
 * Client-side PDF Export via html2pdf.js
 * Isolates the rendered invoice/receipt paper from Tailwind v4 oklch() stylesheets
 * inside html2canvas's cloned DOM so exports succeed cleanly in every browser.
 */

import html2pdf from 'html2pdf.js';
import { renderDocumentPaper } from './templates.js';

/**
 * Generates and downloads an A4 PDF file for the given document.
 */
export async function exportDocumentToPdf(doc, templateStyle) {
  const chosenTemplate = templateStyle || doc.template || 'modern';
  const safeFileBase = (doc.number || doc.type || 'QuickInvoice')
    .replace(/[^a-zA-Z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
  const filename = `${safeFileBase || 'QuickInvoice'}.pdf`;

  // Render an isolated offscreen container at crisp A4 width (794px ~ 210mm at 96dpi)
  const sandbox = document.createElement('div');
  sandbox.style.cssText =
    'position: fixed; left: -10000px; top: 0; width: 794px; background: #ffffff; color: #0f172a; z-index: -1;';
  sandbox.innerHTML = renderDocumentPaper(doc, chosenTemplate);
  document.body.appendChild(sandbox);

  const targetPaper = sandbox.querySelector('#document-preview-paper');

  try {
    // Wait for any uploaded data-URL or external logo image to decode before rasterizing
    const images = Array.from(sandbox.querySelectorAll('img'));
    await Promise.all(
      images.map(
        (img) =>
          new Promise((resolve) => {
            if (img.complete) return resolve();
            img.onload = resolve;
            img.onerror = resolve;
          })
      )
    );

    const options = {
      margin: [8, 8, 8, 8],
      filename,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
        logging: false,
        onclone: (clonedDoc) => {
          // Strip Tailwind v4 stylesheets in the clone (they use oklch() which html2canvas 1.x cannot parse),
          // while preserving our dedicated pure-hex #pdf-paper-styles block.
          const styleNodes = clonedDoc.querySelectorAll('style, link[rel="stylesheet"]');
          styleNodes.forEach((node) => {
            if (node.id !== 'pdf-paper-styles') {
              node.remove();
            }
          });
          clonedDoc.documentElement.classList.remove('dark');
          clonedDoc.documentElement.style.cssText =
            'background-color: #ffffff; color: #0f172a; margin: 0; padding: 0;';
          clonedDoc.body.style.cssText =
            'background-color: #ffffff; color: #0f172a; margin: 0; padding: 0;';
        },
      },
      jsPDF: {
        unit: 'mm',
        format: 'a4',
        orientation: 'portrait',
      },
      pagebreak: { mode: ['avoid-all', 'css', 'legacy'] },
    };

    await html2pdf().set(options).from(targetPaper).save();
  } finally {
    sandbox.remove();
  }
}
