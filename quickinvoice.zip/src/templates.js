/**
 * Professional Invoice & Receipt Templates (Classic and Modern)
 * Uses self-contained pure-hex CSS classes (#pdf-paper-styles in index.html)
 * so both on-screen preview, print, and html2pdf.js PDF exports stay razor sharp.
 */

import {
  calculateDocumentTotals,
  escapeHtml,
  formatCurrency,
  formatDateDisplay,
} from './utils.js';

function getStatusStampHtml(doc) {
  if (doc.type === 'receipt') {
    return '<span class="qi-status-stamp qi-stamp-receipt">PAID RECEIPT</span>';
  }
  if (doc.status === 'paid') {
    return '<span class="qi-status-stamp qi-stamp-paid">PAID</span>';
  }
  return '<span class="qi-status-stamp qi-stamp-pending">PAYMENT DUE</span>';
}

function renderBusinessLines(business) {
  const lines = [];
  if (business.address) lines.push(`<p class="qi-party-line">${escapeHtml(business.address).replace(/\n/g, '<br>')}</p>`);
  if (business.phone) lines.push(`<p class="qi-party-line">Tel: ${escapeHtml(business.phone)}</p>`);
  if (business.email) lines.push(`<p class="qi-party-line">${escapeHtml(business.email)}</p>`);
  if (business.website) lines.push(`<p class="qi-party-line">${escapeHtml(business.website)}</p>`);
  return lines.join('');
}

function renderClientLines(client) {
  const lines = [];
  if (client.address) lines.push(`<p class="qi-party-line">${escapeHtml(client.address).replace(/\n/g, '<br>')}</p>`);
  if (client.phone) lines.push(`<p class="qi-party-line">Tel: ${escapeHtml(client.phone)}</p>`);
  if (client.email) lines.push(`<p class="qi-party-line">${escapeHtml(client.email)}</p>`);
  return lines.join('') || '<p class="qi-party-line" style="color:#94a3b8;">No client contact details provided</p>';
}

function renderItemsRows(items, currency) {
  if (!items.length) {
    return `
      <tr>
        <td colspan="4" class="qi-text-center" style="color:#64748b; padding: 24px 12px;">
          No line items added yet.
        </td>
      </tr>
    `;
  }

  return items
    .map(
      (item, index) => `
      <tr>
        <td class="qi-text-left">
          <div style="font-weight: 500; color: #0f172a;">${escapeHtml(item.description || `Item ${index + 1}`)}</div>
        </td>
        <td class="qi-text-right qi-mono">${item.quantity}</td>
        <td class="qi-text-right qi-mono">${formatCurrency(item.unitPrice, currency)}</td>
        <td class="qi-text-right qi-mono" style="font-weight: 600; color: #0f172a;">${formatCurrency(item.amount, currency)}</td>
      </tr>
    `
    )
    .join('');
}

function renderTotalsSection(doc, totals, variant) {
  const isModern = variant === 'modern';
  const totalLabel = doc.type === 'receipt' ? 'Total Paid' : 'Total Due';

  const discountLabel =
    totals.discountType === 'percent' && totals.discountValue > 0
      ? `Discount (${totals.discountValue}%)`
      : 'Discount';

  return `
    <div class="qi-bottom-grid">
      <div class="qi-notes-col">
        ${
          doc.notes && doc.notes.trim()
            ? `
          <p class="qi-notes-title">${doc.type === 'receipt' ? 'Receipt Notes' : 'Notes &amp; Payment Terms'}</p>
          <p class="qi-notes-text">${escapeHtml(doc.notes)}</p>
        `
            : ''
        }
      </div>

      <div class="qi-totals-col">
        <div class="qi-totals-row">
          <span>Subtotal</span>
          <span class="qi-mono qi-totals-row-strong">${formatCurrency(totals.subtotal, doc.currency)}</span>
        </div>
        ${
          totals.taxRate > 0
            ? `
          <div class="qi-totals-row">
            <span>Tax / VAT (${totals.taxRate}%)</span>
            <span class="qi-mono qi-totals-row-strong">${formatCurrency(totals.taxAmount, doc.currency)}</span>
          </div>
        `
            : ''
        }
        ${
          totals.discountAmount > 0
            ? `
          <div class="qi-totals-row">
            <span>${discountLabel}</span>
            <span class="qi-mono" style="color: #dc2626; font-weight: 600;">-${formatCurrency(totals.discountAmount, doc.currency)}</span>
          </div>
        `
            : ''
        }
        <div class="${isModern ? 'qi-grand-total-modern' : 'qi-grand-total-classic'}">
          <span>${totalLabel}</span>
          <span class="qi-mono">${formatCurrency(totals.total, doc.currency)}</span>
        </div>
      </div>
    </div>
  `;
}

/**
 * Classic Executive Template
 */
function renderClassicTemplate(doc, totals) {
  const isInvoice = doc.type === 'invoice';
  const docTitle = isInvoice ? 'Invoice' : 'Receipt';
  const businessName = doc.business?.name || 'Your Business Name';
  const clientName = doc.client?.name || 'Client Name';

  return `
    <div id="document-preview-paper" class="qi-paper qi-classic">
      <div class="qi-classic-header">
        <div>
          ${
            doc.business?.logo
              ? `<img src="${doc.business.logo}" alt="${escapeHtml(businessName)} logo" class="qi-logo-box" />`
              : ''
          }
          <h2 class="qi-display" style="font-size: 20px; font-weight: 700; margin: 0 0 6px 0; color: #0f172a;">
            ${escapeHtml(businessName)}
          </h2>
          ${renderBusinessLines(doc.business || {})}
        </div>

        <div style="text-align: right;">
          <h1 class="qi-display qi-classic-title">${docTitle}</h1>
          <div style="margin-bottom: 12px;">${getStatusStampHtml(doc)}</div>
          <table class="qi-classic-meta-table">
            <tr>
              <td class="qi-classic-meta-label">${docTitle} No.</td>
              <td class="qi-classic-meta-val qi-mono">${escapeHtml(doc.number || '—')}</td>
            </tr>
            <tr>
              <td class="qi-classic-meta-label">Issue Date</td>
              <td class="qi-classic-meta-val">${formatDateDisplay(doc.date)}</td>
            </tr>
            ${
              isInvoice && doc.dueDate
                ? `
              <tr>
                <td class="qi-classic-meta-label">Due Date</td>
                <td class="qi-classic-meta-val">${formatDateDisplay(doc.dueDate)}</td>
              </tr>
            `
                : ''
            }
            <tr>
              <td class="qi-classic-meta-label">Currency</td>
              <td class="qi-classic-meta-val qi-mono">${escapeHtml(doc.currency || 'NGN')}</td>
            </tr>
          </table>
        </div>
      </div>

      <div class="qi-parties-grid">
        <div>
          <p class="qi-party-label">${isInvoice ? 'Billed To' : 'Received From'}</p>
          <p class="qi-party-name">${escapeHtml(clientName)}</p>
          ${renderClientLines(doc.client || {})}
        </div>
        <div style="text-align: right;">
          <p class="qi-party-label">Summary</p>
          <p class="qi-party-line">
            ${isInvoice ? 'Amount Due' : 'Amount Paid'}:
            <strong class="qi-mono" style="color:#0f172a;">${formatCurrency(totals.total, doc.currency)}</strong>
          </p>
          <p class="qi-party-line">Items: <span class="qi-mono">${totals.items.length}</span></p>
        </div>
      </div>

      <table class="qi-table">
        <thead>
          <tr>
            <th class="qi-text-left" style="width: 48%;">Description</th>
            <th class="qi-text-right" style="width: 14%;">Qty</th>
            <th class="qi-text-right" style="width: 19%;">Unit Price</th>
            <th class="qi-text-right" style="width: 19%;">Amount</th>
          </tr>
        </thead>
        <tbody>
          ${renderItemsRows(totals.items, doc.currency)}
        </tbody>
      </table>

      ${renderTotalsSection(doc, totals, 'classic')}

      <div class="qi-paper-footer">
        Generated with QuickInvoice · ${escapeHtml(businessName)}
      </div>
    </div>
  `;
}

/**
 * Modern Cobalt Blue Template
 */
function renderModernTemplate(doc, totals) {
  const isInvoice = doc.type === 'invoice';
  const docTitle = isInvoice ? 'Invoice' : 'Official Receipt';
  const businessName = doc.business?.name || 'Your Business Name';
  const clientName = doc.client?.name || 'Client Name';

  return `
    <div id="document-preview-paper" class="qi-paper qi-modern">
      <div class="qi-modern-banner ${isInvoice ? '' : 'qi-modern-banner-receipt'}">
        <div>
          ${
            doc.business?.logo
              ? `<img src="${doc.business.logo}" alt="${escapeHtml(businessName)} logo" class="qi-logo-box-modern" />`
              : ''
          }
          <h2 class="qi-display" style="font-size: 20px; font-weight: 700; margin: 0 0 4px 0; color: #ffffff;">
            ${escapeHtml(businessName)}
          </h2>
          ${
            doc.business?.email || doc.business?.phone
              ? `<p class="qi-modern-sub">${[doc.business.email, doc.business.phone].filter(Boolean).map(escapeHtml).join(' · ')}</p>`
              : ''
          }
        </div>

        <div style="text-align: right;">
          <h1 class="qi-display qi-modern-doc-title">${docTitle}</h1>
          <p class="qi-modern-sub qi-mono" style="font-size: 14px; font-weight: 600; color: #ffffff;">
            #${escapeHtml(doc.number || '—')}
          </p>
          <div style="margin-top: 10px;">
            ${getStatusStampHtml(doc)}
          </div>
        </div>
      </div>

      <div class="qi-modern-body">
        <div class="qi-modern-meta-strip">
          <div>
            <p class="qi-modern-meta-item-label">Document No.</p>
            <p class="qi-modern-meta-item-val qi-mono">${escapeHtml(doc.number || '—')}</p>
          </div>
          <div>
            <p class="qi-modern-meta-item-label">Date Issued</p>
            <p class="qi-modern-meta-item-val">${formatDateDisplay(doc.date)}</p>
          </div>
          <div>
            <p class="qi-modern-meta-item-label">${isInvoice ? 'Due Date' : 'Status'}</p>
            <p class="qi-modern-meta-item-val">${isInvoice ? formatDateDisplay(doc.dueDate) : 'Paid in Full'}</p>
          </div>
          <div>
            <p class="qi-modern-meta-item-label">Currency</p>
            <p class="qi-modern-meta-item-val qi-mono">${escapeHtml(doc.currency || 'NGN')}</p>
          </div>
        </div>

        <div class="qi-parties-grid" style="margin-top: 0;">
          <div>
            <p class="qi-party-label">From</p>
            <p class="qi-party-name">${escapeHtml(businessName)}</p>
            ${renderBusinessLines(doc.business || {})}
          </div>
          <div>
            <p class="qi-party-label">${isInvoice ? 'Bill To' : 'Received From'}</p>
            <p class="qi-party-name">${escapeHtml(clientName)}</p>
            ${renderClientLines(doc.client || {})}
          </div>
        </div>

        <table class="qi-table">
          <thead>
            <tr>
              <th class="qi-text-left" style="width: 48%;">Item Description</th>
              <th class="qi-text-right" style="width: 14%;">Qty</th>
              <th class="qi-text-right" style="width: 19%;">Unit Price</th>
              <th class="qi-text-right" style="width: 19%;">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${renderItemsRows(totals.items, doc.currency)}
          </tbody>
        </table>

        ${renderTotalsSection(doc, totals, 'modern')}

        <div class="qi-paper-footer">
          Thank you for choosing ${escapeHtml(businessName)}.
        </div>
      </div>
    </div>
  `;
}

/**
 * Entry point: returns the formatted HTML for either Classic or Modern style.
 */
export function renderDocumentPaper(doc, styleOverride) {
  const templateStyle = styleOverride || doc.template || 'modern';
  const totals = calculateDocumentTotals(doc);
  if (templateStyle === 'classic') {
    return renderClassicTemplate(doc, totals);
  }
  return renderModernTemplate(doc, totals);
}
