/**
 * QuickInvoice — Main Application Controller (Vanilla JavaScript)
 * Manages routing, application state, DOM rendering, event delegation,
 * real-time invoice/receipt math, dark mode, PDF export, and localStorage sync.
 */

import './index.css';
import {
  createIcons,
  FileText,
  Receipt,
  Plus,
  Trash2,
  Download,
  Printer,
  Eye,
  Save,
  Edit3,
  CheckCircle2,
  Clock,
  AlertCircle,
  Sun,
  Moon,
  Search,
  ArrowLeft,
  Upload,
  X,
  FolderOpen,
  Building2,
  User,
  Hash,
  Check,
  LayoutTemplate,
} from 'lucide';

import {
  createEmptyDocument,
  deleteDocument,
  generateDocumentNumber,
  getDocumentById,
  getDocuments,
  getSavedTheme,
  saveBusinessProfile,
  saveDocument,
  saveTheme,
  toggleInvoicePaidStatus,
} from './storage.js';
import {
  CURRENCIES,
  calculateDocumentTotals,
  escapeHtml,
  formatCurrency,
  formatDateDisplay,
  generateId,
  getOffsetDateISO,
  isInvoiceOverdue,
} from './utils.js';
import { renderDocumentPaper } from './templates.js';
import { exportDocumentToPdf } from './pdf.js';

const ICONS = {
  FileText,
  Receipt,
  Plus,
  Trash2,
  Download,
  Printer,
  Eye,
  Save,
  Edit3,
  CheckCircle2,
  Clock,
  AlertCircle,
  Sun,
  Moon,
  Search,
  ArrowLeft,
  Upload,
  X,
  FolderOpen,
  Building2,
  User,
  Hash,
  Check,
  LayoutTemplate,
};

/**
 * Central client-side state
 */
const state = {
  view: 'dashboard', // 'dashboard' | 'editor' | 'preview' | 'history'
  previousView: 'dashboard',
  draft: createEmptyDocument('invoice'),
  isEditingExisting: false,
  historyFilter: 'all', // 'all' | 'invoice' | 'receipt' | 'paid' | 'pending'
  historySearch: '',
  deleteModalDocId: null,
  isExportingPdf: false,
  darkMode: document.documentElement.classList.contains('dark'),
};

const appRoot = document.getElementById('app');

/* -------------------------------------------------------------------------- */
/* Theme & Icon Hydration                                                     */
/* -------------------------------------------------------------------------- */

function refreshIcons() {
  createIcons({ icons: ICONS });
}

function toggleDarkMode() {
  state.darkMode = !state.darkMode;
  document.documentElement.classList.toggle('dark', state.darkMode);
  saveTheme(state.darkMode ? 'dark' : 'light');
  render();
}

function syncThemeOnInit() {
  const saved = getSavedTheme();
  if (saved === 'dark') {
    state.darkMode = true;
    document.documentElement.classList.add('dark');
  } else if (saved === 'light') {
    state.darkMode = false;
    document.documentElement.classList.remove('dark');
  }
}

/* -------------------------------------------------------------------------- */
/* Non-blocking Toast Notifications                                           */
/* -------------------------------------------------------------------------- */

let toastTimer = null;

function showToast(message, variant = 'success') {
  const existing = document.getElementById('qi-toast');
  if (existing) existing.remove();
  if (toastTimer) clearTimeout(toastTimer);

  const toast = document.createElement('div');
  toast.id = 'qi-toast';
  toast.setAttribute('role', 'status');
  toast.className = `no-print fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-lg shadow-lg border text-sm font-medium transition-all duration-200 ${
    variant === 'error'
      ? 'bg-red-600 text-white border-red-700'
      : 'bg-slate-900 text-white border-slate-800 dark:bg-white dark:text-slate-900 dark:border-slate-200'
  }`;

  const iconName = variant === 'error' ? 'alert-circle' : 'check-circle-2';
  toast.innerHTML = `<i data-lucide="${iconName}" class="w-4 h-4 shrink-0"></i><span>${escapeHtml(message)}</span>`;
  document.body.appendChild(toast);
  refreshIcons();

  toastTimer = setTimeout(() => {
    toast.classList.add('opacity-0', 'translate-y-2');
    setTimeout(() => toast.remove(), 200);
  }, 2800);
}

/* -------------------------------------------------------------------------- */
/* Navigation & Document Workflows                                            */
/* -------------------------------------------------------------------------- */

function navigateTo(view) {
  if (view !== state.view) {
    state.previousView = state.view;
  }
  state.view = view;
  window.scrollTo({ top: 0, behavior: 'smooth' });
  render();
}

function startNewDocument(type) {
  state.draft = createEmptyDocument(type);
  state.isEditingExisting = false;
  navigateTo('editor');
}

function editSavedDocument(id) {
  const existing = getDocumentById(id);
  if (!existing) {
    showToast('Document could not be found.', 'error');
    return;
  }
  state.draft = JSON.parse(JSON.stringify(existing));
  state.isEditingExisting = true;
  navigateTo('editor');
}

function previewSavedDocument(id) {
  const existing = getDocumentById(id);
  if (!existing) {
    showToast('Document could not be found.', 'error');
    return;
  }
  state.draft = JSON.parse(JSON.stringify(existing));
  state.isEditingExisting = true;
  navigateTo('preview');
}

function saveCurrentDraft(showFeedback = true) {
  if (!state.draft.number || !state.draft.number.trim()) {
    state.draft.number = generateDocumentNumber(state.draft.type);
  }
  const saved = saveDocument(state.draft);
  state.draft = JSON.parse(JSON.stringify(saved));
  state.isEditingExisting = true;
  if (showFeedback) {
    const label = saved.type === 'receipt' ? 'Receipt' : 'Invoice';
    showToast(`${label} ${saved.number} saved to History.`);
  }
  return saved;
}

async function handleDownloadPdf(doc) {
  if (state.isExportingPdf) return;
  state.isExportingPdf = true;
  updatePdfButtonsLoading(true);
  try {
    await exportDocumentToPdf(doc, doc.template);
    showToast(`Downloaded ${doc.number || doc.type}.pdf`);
  } catch (err) {
    console.error('PDF export error:', err);
    showToast('Could not generate PDF. Try Print instead.', 'error');
  } finally {
    state.isExportingPdf = false;
    updatePdfButtonsLoading(false);
  }
}

function updatePdfButtonsLoading(isLoading) {
  document.querySelectorAll('[data-pdf-trigger]').forEach((btn) => {
    btn.disabled = isLoading;
    const label = btn.querySelector('[data-pdf-label]');
    if (label) {
      label.textContent = isLoading ? 'Exporting...' : 'Download PDF';
    }
  });
}

/* -------------------------------------------------------------------------- */
/* Shared UI Helpers                                                          */
/* -------------------------------------------------------------------------- */

function getStatusBadgeMarkup(doc) {
  if (doc.type === 'receipt') {
    return `
      <span class="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 dark:text-blue-400 whitespace-nowrap">
        <i data-lucide="check-circle-2" class="w-3.5 h-3.5 shrink-0"></i>
        <span>Issued</span>
      </span>
    `;
  }
  if (doc.status === 'paid') {
    return `
      <span class="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400 whitespace-nowrap">
        <i data-lucide="check-circle-2" class="w-3.5 h-3.5 shrink-0"></i>
        <span>Paid</span>
      </span>
    `;
  }
  if (isInvoiceOverdue(doc)) {
    return `
      <span class="inline-flex items-center gap-1.5 text-xs font-medium text-red-600 dark:text-red-400 whitespace-nowrap">
        <i data-lucide="alert-circle" class="w-3.5 h-3.5 shrink-0"></i>
        <span>Overdue</span>
      </span>
    `;
  }
  return `
    <span class="inline-flex items-center gap-1.5 text-xs font-medium text-amber-600 dark:text-amber-400 whitespace-nowrap">
      <i data-lucide="clock" class="w-3.5 h-3.5 shrink-0"></i>
      <span>Pending</span>
    </span>
  `;
}

/* -------------------------------------------------------------------------- */
/* Top Navigation Bar (Strict 3-Zone Top Bar Contract)                        */
/* -------------------------------------------------------------------------- */

function renderHeader() {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'new-invoice', label: 'Create Invoice', active: state.view === 'editor' && state.draft.type === 'invoice' },
    { id: 'new-receipt', label: 'Create Receipt', active: state.view === 'editor' && state.draft.type === 'receipt' },
    { id: 'history', label: 'History' },
  ];

  return `
    <header class="no-print bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <div class="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        <!-- Zone 1: Single-line Brand Wordmark -->
        <button
          type="button"
          data-action="go-dashboard"
          class="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded"
        >
          Quick<span class="text-blue-600 dark:text-blue-400">Invoice</span>
        </button>

        <!-- Zone 2: Clean Single-Line Navigation Links -->
        <nav aria-label="Primary Navigation" class="hidden md:flex items-center gap-6 text-sm font-medium">
          ${navItems
            .map((item) => {
              const isActive = item.active !== undefined ? item.active : state.view === item.id;
              return `
                <button
                  type="button"
                  data-nav="${item.id}"
                  class="py-1 whitespace-nowrap shrink-0 cursor-pointer transition-colors border-b-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded-sm ${
                    isActive
                      ? 'text-blue-600 dark:text-blue-400 border-blue-600 dark:border-blue-400'
                      : 'text-slate-600 dark:text-slate-300 border-transparent hover:text-slate-900 dark:hover:text-white'
                  }"
                >
                  ${item.label}
                </button>
              `;
            })
            .join('')}
        </nav>

        <!-- Zone 3: Single Utility Action (Dark Mode Toggle) -->
        <div class="flex items-center shrink-0">
          <button
            type="button"
            data-action="toggle-theme"
            aria-label="Toggle dark mode"
            class="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 min-h-[40px]"
          >
            <i data-lucide="${state.darkMode ? 'sun' : 'moon'}" class="w-4 h-4"></i>
            <span>${state.darkMode ? 'Light Mode' : 'Dark Mode'}</span>
          </button>
        </div>
      </div>

      <!-- Mobile Navigation Strip -->
      <nav aria-label="Mobile Navigation" class="md:hidden border-t border-slate-200 dark:border-slate-800 px-2 py-1.5 flex items-center justify-between gap-1 overflow-x-auto">
        ${navItems
          .map((item) => {
            const isActive = item.active !== undefined ? item.active : state.view === item.id;
            return `
              <button
                type="button"
                data-nav="${item.id}"
                class="flex-1 text-center px-2.5 py-2 text-xs font-medium rounded-md whitespace-nowrap shrink-0 cursor-pointer transition-colors min-h-[40px] ${
                  isActive
                    ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }"
              >
                ${item.label}
              </button>
            `;
          })
          .join('')}
      </nav>
    </header>
  `;
}

/* -------------------------------------------------------------------------- */
/* 1. Dashboard View                                                          */
/* -------------------------------------------------------------------------- */

function renderDashboard() {
  const docs = getDocuments();
  const recentDocs = docs.slice(0, 6);

  const invoiceCount = docs.filter((d) => d.type === 'invoice').length;
  const receiptCount = docs.filter((d) => d.type === 'receipt').length;
  const pendingCount = docs.filter((d) => d.type === 'invoice' && d.status !== 'paid').length;
  const paidInvoicesCount = docs.filter((d) => d.type === 'invoice' && d.status === 'paid').length;

  // Summarize paid volume in the most frequently used currency (defaults to NGN)
  const currencyTotals = {};
  docs.forEach((d) => {
    if (d.type === 'receipt' || d.status === 'paid') {
      const curr = d.currency || 'NGN';
      const { total } = calculateDocumentTotals(d);
      currencyTotals[curr] = (currencyTotals[curr] || 0) + total;
    }
  });
  const primaryCurrency = currencyTotals.NGN !== undefined ? 'NGN' : Object.keys(currencyTotals)[0] || 'NGN';
  const collectedPrimary = currencyTotals[primaryCurrency] || 0;

  return `
    <main class="max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-10 space-y-8">
      <!-- Hero Action Panel -->
      <section class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 sm:p-8">
        <div class="max-w-2xl">
          <h1 class="font-display text-2xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white [text-wrap:balance]">
            Invoicing and receipts built for speed.
          </h1>
          <p class="mt-2.5 text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
            Create clean invoices and payment receipts, preview Classic or Modern layouts, and export ready-to-send PDFs right from your browser.
          </p>
        </div>

        <!-- Two Big Action Buttons -->
        <div class="mt-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            type="button"
            data-action="new-invoice"
            class="group flex items-center justify-between gap-4 p-5 sm:p-6 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-left transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900 min-h-[88px]"
          >
            <div class="flex items-center gap-4 min-w-0">
              <div class="w-12 h-12 rounded-lg bg-blue-500/40 flex items-center justify-center shrink-0">
                <i data-lucide="file-text" class="w-6 h-6 text-white"></i>
              </div>
              <div class="min-w-0">
                <span class="block font-display text-lg font-bold text-white">Create Invoice</span>
                <span class="block text-xs sm:text-sm text-blue-100 mt-0.5">Bill clients with due dates, tax, and terms</span>
              </div>
            </div>
            <i data-lucide="plus" class="w-5 h-5 text-blue-100 group-hover:translate-x-0.5 transition-transform shrink-0"></i>
          </button>

          <button
            type="button"
            data-action="new-receipt"
            class="group flex items-center justify-between gap-4 p-5 sm:p-6 rounded-xl bg-white dark:bg-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-blue-600 dark:hover:border-blue-500 text-left transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 min-h-[88px]"
          >
            <div class="flex items-center gap-4 min-w-0">
              <div class="w-12 h-12 rounded-lg bg-blue-50 dark:bg-blue-950/80 flex items-center justify-center shrink-0">
                <i data-lucide="receipt" class="w-6 h-6 text-blue-600 dark:text-blue-400"></i>
              </div>
              <div class="min-w-0">
                <span class="block font-display text-lg font-bold text-slate-900 dark:text-white">Create Receipt</span>
                <span class="block text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-0.5">Issue instant proof of payment for customers</span>
              </div>
            </div>
            <i data-lucide="plus" class="w-5 h-5 text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors shrink-0"></i>
          </button>
        </div>

        <!-- 3-Column Summary Strip (Real localStorage metrics) -->
        <div class="mt-7 pt-6 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div>
            <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Saved Documents</p>
            <p class="mt-1 font-display text-2xl font-bold text-slate-900 dark:text-white tabular-nums">${docs.length}</p>
            <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400 tabular-nums">${invoiceCount} invoices · ${receiptCount} receipts</p>
          </div>
          <div>
            <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Collected (${primaryCurrency})</p>
            <p class="mt-1 font-mono text-2xl font-semibold text-slate-900 dark:text-white tabular-nums">${formatCurrency(collectedPrimary, primaryCurrency)}</p>
            <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400 tabular-nums">${paidInvoicesCount + receiptCount} paid records</p>
          </div>
          <div>
            <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Pending Invoices</p>
            <p class="mt-1 font-display text-2xl font-bold text-slate-900 dark:text-white tabular-nums">${pendingCount}</p>
            <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">${pendingCount === 0 ? 'All invoices settled' : 'Awaiting payment'}</p>
          </div>
        </div>
      </section>

      <!-- Recent Invoices & Receipts -->
      <section class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div class="px-5 sm:px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4">
          <div>
            <h2 class="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white">Recent Invoices &amp; Receipts</h2>
          </div>
          ${
            docs.length > 0
              ? `
            <button
              type="button"
              data-nav="history"
              class="text-xs sm:text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
            >
              View All (${docs.length})
            </button>
          `
              : ''
          }
        </div>

        ${
          recentDocs.length === 0
            ? renderEmptyState(
                'No invoices or receipts yet',
                'Create your first invoice or receipt above. Saved documents appear here and stay stored in your browser.'
              )
            : renderDocumentTable(recentDocs)
        }
      </section>
    </main>
  `;
}

function renderEmptyState(title, description) {
  return `
    <div class="px-6 py-12 text-center">
      <div class="w-12 h-12 mx-auto rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 dark:text-slate-500">
        <i data-lucide="folder-open" class="w-6 h-6"></i>
      </div>
      <h3 class="mt-4 font-display text-base font-semibold text-slate-900 dark:text-white">${escapeHtml(title)}</h3>
      <p class="mt-1.5 text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">${escapeHtml(description)}</p>
      <div class="mt-5 flex flex-wrap items-center justify-center gap-3">
        <button
          type="button"
          data-action="new-invoice"
          class="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors whitespace-nowrap cursor-pointer min-h-[42px]"
        >
          <i data-lucide="plus" class="w-4 h-4"></i>
          <span>Create Invoice</span>
        </button>
        <button
          type="button"
          data-action="new-receipt"
          class="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors whitespace-nowrap cursor-pointer min-h-[42px]"
        >
          <i data-lucide="receipt" class="w-4 h-4"></i>
          <span>Create Receipt</span>
        </button>
      </div>
    </div>
  `;
}

function renderDocumentTable(docs) {
  return `
    <!-- Desktop Table -->
    <div class="hidden md:block overflow-x-auto">
      <table class="w-full text-left border-collapse">
        <thead>
          <tr class="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60 text-xs font-semibold text-slate-500 dark:text-slate-400">
            <th class="py-3 px-6">Number</th>
            <th class="py-3 px-4">Type</th>
            <th class="py-3 px-4">Client</th>
            <th class="py-3 px-4">Date</th>
            <th class="py-3 px-4">Status</th>
            <th class="py-3 px-4 text-right">Amount</th>
            <th class="py-3 px-6 text-right">Actions</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-200 dark:divide-slate-800 text-sm">
          ${docs
            .map((doc) => {
              const { total } = calculateDocumentTotals(doc);
              const isInvoice = doc.type === 'invoice';
              return `
                <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                  <td class="py-3.5 px-6 font-mono font-medium text-slate-900 dark:text-white whitespace-nowrap">
                    <button type="button" data-doc-preview="${doc.id}" class="hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer">
                      ${escapeHtml(doc.number || '—')}
                    </button>
                  </td>
                  <td class="py-3.5 px-4 text-slate-600 dark:text-slate-300 whitespace-nowrap">
                    ${isInvoice ? 'Invoice' : 'Receipt'}
                  </td>
                  <td class="py-3.5 px-4 text-slate-900 dark:text-slate-100 font-medium max-w-[200px] truncate">
                    ${escapeHtml(doc.client?.name || 'Unnamed Client')}
                  </td>
                  <td class="py-3.5 px-4 text-slate-500 dark:text-slate-400 whitespace-nowrap tabular-nums">
                    ${formatDateDisplay(doc.date)}
                  </td>
                  <td class="py-3.5 px-4 whitespace-nowrap">
                    ${getStatusBadgeMarkup(doc)}
                  </td>
                  <td class="py-3.5 px-4 text-right font-mono font-semibold text-slate-900 dark:text-white whitespace-nowrap tabular-nums">
                    ${formatCurrency(total, doc.currency)}
                  </td>
                  <td class="py-3.5 px-6 text-right whitespace-nowrap">
                    <div class="inline-flex items-center justify-end gap-1">
                      ${
                        isInvoice
                          ? `
                        <button
                          type="button"
                          data-doc-toggle-paid="${doc.id}"
                          title="${doc.status === 'paid' ? 'Mark as Pending' : 'Mark as Paid'}"
                          class="px-2.5 py-1.5 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition-colors cursor-pointer whitespace-nowrap"
                        >
                          ${doc.status === 'paid' ? 'Unmark Paid' : 'Mark Paid'}
                        </button>
                      `
                          : ''
                      }
                      <button
                        type="button"
                        data-doc-preview="${doc.id}"
                        aria-label="Preview document"
                        title="View Preview"
                        class="p-2 rounded-md text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:text-slate-400 dark:hover:text-blue-400 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        <i data-lucide="eye" class="w-4 h-4"></i>
                      </button>
                      <button
                        type="button"
                        data-doc-edit="${doc.id}"
                        aria-label="Edit document"
                        title="Edit"
                        class="p-2 rounded-md text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:text-slate-400 dark:hover:text-blue-400 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        <i data-lucide="edit-3" class="w-4 h-4"></i>
                      </button>
                      <button
                        type="button"
                        data-doc-download="${doc.id}"
                        aria-label="Download PDF"
                        title="Download PDF"
                        class="p-2 rounded-md text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:text-slate-400 dark:hover:text-blue-400 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        <i data-lucide="download" class="w-4 h-4"></i>
                      </button>
                      <button
                        type="button"
                        data-doc-delete="${doc.id}"
                        aria-label="Delete document"
                        title="Delete"
                        class="p-2 rounded-md text-slate-500 hover:text-red-600 hover:bg-red-50 dark:text-slate-400 dark:hover:text-red-400 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              `;
            })
            .join('')}
        </tbody>
      </table>
    </div>

    <!-- Mobile List Cards -->
    <div class="md:hidden divide-y divide-slate-200 dark:divide-slate-800">
      ${docs
        .map((doc) => {
          const { total } = calculateDocumentTotals(doc);
          const isInvoice = doc.type === 'invoice';
          return `
            <div class="p-4 space-y-3">
              <div class="flex items-start justify-between gap-3">
                <div class="min-w-0">
                  <button type="button" data-doc-preview="${doc.id}" class="font-mono text-sm font-semibold text-slate-900 dark:text-white hover:text-blue-600 text-left">
                    ${escapeHtml(doc.number || '—')}
                  </button>
                  <p class="text-sm font-medium text-slate-800 dark:text-slate-200 truncate mt-0.5">
                    ${escapeHtml(doc.client?.name || 'Unnamed Client')}
                  </p>
                  <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    ${isInvoice ? 'Invoice' : 'Receipt'} · ${formatDateDisplay(doc.date)}
                  </p>
                </div>
                <div class="text-right shrink-0">
                  <p class="font-mono text-sm font-bold text-slate-900 dark:text-white tabular-nums">
                    ${formatCurrency(total, doc.currency)}
                  </p>
                  <div class="mt-1 flex justify-end">
                    ${getStatusBadgeMarkup(doc)}
                  </div>
                </div>
              </div>

              <div class="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="button"
                  data-doc-preview="${doc.id}"
                  class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 min-h-[38px]"
                >
                  <i data-lucide="eye" class="w-3.5 h-3.5"></i>
                  <span>View</span>
                </button>
                <button
                  type="button"
                  data-doc-edit="${doc.id}"
                  class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 min-h-[38px]"
                >
                  <i data-lucide="edit-3" class="w-3.5 h-3.5"></i>
                  <span>Edit</span>
                </button>
                <button
                  type="button"
                  data-doc-download="${doc.id}"
                  class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 min-h-[38px]"
                >
                  <i data-lucide="download" class="w-3.5 h-3.5"></i>
                  <span>PDF</span>
                </button>
                ${
                  isInvoice
                    ? `
                  <button
                    type="button"
                    data-doc-toggle-paid="${doc.id}"
                    class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 min-h-[38px]"
                  >
                    <i data-lucide="check" class="w-3.5 h-3.5"></i>
                    <span>${doc.status === 'paid' ? 'Unpaid' : 'Mark Paid'}</span>
                  </button>
                `
                    : ''
                }
                <button
                  type="button"
                  data-doc-delete="${doc.id}"
                  aria-label="Delete"
                  class="ml-auto inline-flex items-center justify-center p-2 text-xs font-medium rounded-lg border border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 min-h-[38px] min-w-[38px]"
                >
                  <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                </button>
              </div>
            </div>
          `;
        })
        .join('')}
    </div>
  `;
}

/* -------------------------------------------------------------------------- */
/* 2. Create / Edit Invoice or Receipt Page                                   */
/* -------------------------------------------------------------------------- */

function renderEditor() {
  const doc = state.draft;
  const isInvoice = doc.type === 'invoice';
  const totals = calculateDocumentTotals(doc);
  const inputClass =
    'w-full px-3.5 py-2.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-shadow min-h-[42px]';
  const labelClass = 'block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5';

  return `
    <main class="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
      <!-- Page Subheader -->
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div class="flex items-center gap-3">
          <button
            type="button"
            data-action="go-back"
            class="inline-flex items-center justify-center w-10 h-10 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer shrink-0"
            aria-label="Back"
          >
            <i data-lucide="arrow-left" class="w-4 h-4"></i>
          </button>
          <div>
            <h1 class="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              ${state.isEditingExisting ? `Edit ${isInvoice ? 'Invoice' : 'Receipt'}` : `Create ${isInvoice ? 'Invoice' : 'Receipt'}`}
            </h1>
            <p class="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              ${escapeHtml(doc.number || '')} · Auto-calculates amounts and saves locally
            </p>
          </div>
        </div>

        <!-- Document Type Segmented Switcher (when creating new) -->
        ${
          !state.isEditingExisting
            ? `
          <div class="inline-flex items-center p-1 rounded-lg bg-slate-200/70 dark:bg-slate-800 self-start sm:self-auto">
            <button
              type="button"
              data-switch-type="invoice"
              class="px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                isInvoice
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }"
            >
              Invoice
            </button>
            <button
              type="button"
              data-switch-type="receipt"
              class="px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                !isInvoice
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }"
            >
              Receipt
            </button>
          </div>
        `
            : ''
        }
      </div>

      <!-- Main Editor Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <!-- Left Column: Form Inputs -->
        <div class="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-200 dark:divide-slate-800">
          <!-- Section 1: Business Details -->
          <section class="p-5 sm:p-6 space-y-4">
            <div class="flex items-center justify-between gap-4">
              <div class="flex items-center gap-2">
                <i data-lucide="building-2" class="w-4 h-4 text-blue-600 dark:text-blue-400"></i>
                <h2 class="font-display text-base font-bold text-slate-900 dark:text-white">Business Details</h2>
              </div>
              <span class="text-xs text-slate-500 dark:text-slate-400">Remembered automatically</span>
            </div>

            <!-- Logo Upload Row -->
            <div class="flex flex-wrap items-center gap-4 pt-1">
              ${
                doc.business.logo
                  ? `
                <div class="relative inline-flex items-center gap-3 p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                  <img src="${doc.business.logo}" alt="Business logo preview" class="h-12 max-w-[140px] object-contain rounded" />
                  <button
                    type="button"
                    data-action="remove-logo"
                    class="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 rounded-md cursor-pointer"
                  >
                    <i data-lucide="x" class="w-3.5 h-3.5"></i>
                    <span>Remove</span>
                  </button>
                </div>
              `
                  : `
                <label class="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg border border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-600 dark:hover:border-blue-500 text-slate-700 dark:text-slate-200 bg-slate-50/60 dark:bg-slate-800/50 cursor-pointer transition-colors min-h-[42px]">
                  <i data-lucide="upload" class="w-4 h-4 text-blue-600 dark:text-blue-400"></i>
                  <span>Upload Business Logo (Optional)</span>
                  <input type="file" id="logo-file-input" accept="image/png,image/jpeg,image/webp,image/svg+xml" class="hidden" />
                </label>
              `
              }
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div class="sm:col-span-2">
                <label for="biz-name" class="${labelClass}">Business Name</label>
                <input id="biz-name" type="text" data-field="business.name" value="${escapeHtml(doc.business.name)}" placeholder="e.g., Lagos Digital Studio Ltd." class="${inputClass}" />
              </div>
              <div>
                <label for="biz-email" class="${labelClass}">Email</label>
                <input id="biz-email" type="email" data-field="business.email" value="${escapeHtml(doc.business.email)}" placeholder="billing@yourbusiness.com" class="${inputClass}" />
              </div>
              <div>
                <label for="biz-phone" class="${labelClass}">Phone</label>
                <input id="biz-phone" type="tel" data-field="business.phone" value="${escapeHtml(doc.business.phone)}" placeholder="+234 800 000 0000" class="${inputClass}" />
              </div>
              <div>
                <label for="biz-address" class="${labelClass}">Address</label>
                <input id="biz-address" type="text" data-field="business.address" value="${escapeHtml(doc.business.address)}" placeholder="14 Admiralty Way, Lekki, Lagos" class="${inputClass}" />
              </div>
              <div>
                <label for="biz-website" class="${labelClass}">Website (Optional)</label>
                <input id="biz-website" type="text" data-field="business.website" value="${escapeHtml(doc.business.website)}" placeholder="https://yourbusiness.com" class="${inputClass}" />
              </div>
            </div>
          </section>

          <!-- Section 2: Client Details -->
          <section class="p-5 sm:p-6 space-y-4">
            <div class="flex items-center gap-2">
              <i data-lucide="user" class="w-4 h-4 text-blue-600 dark:text-blue-400"></i>
              <h2 class="font-display text-base font-bold text-slate-900 dark:text-white">Client Details</h2>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label for="client-name" class="${labelClass}">Client Name</label>
                <input id="client-name" type="text" data-field="client.name" value="${escapeHtml(doc.client.name)}" placeholder="e.g., Apex Retail Nigeria" class="${inputClass}" />
              </div>
              <div>
                <label for="client-email" class="${labelClass}">Client Email</label>
                <input id="client-email" type="email" data-field="client.email" value="${escapeHtml(doc.client.email)}" placeholder="accounts@client.com" class="${inputClass}" />
              </div>
              <div>
                <label for="client-address" class="${labelClass}">Client Address</label>
                <input id="client-address" type="text" data-field="client.address" value="${escapeHtml(doc.client.address)}" placeholder="22 Broad Street, Lagos" class="${inputClass}" />
              </div>
              <div>
                <label for="client-phone" class="${labelClass}">Client Phone</label>
                <input id="client-phone" type="tel" data-field="client.phone" value="${escapeHtml(doc.client.phone)}" placeholder="+234 801 234 5678" class="${inputClass}" />
              </div>
            </div>
          </section>

          <!-- Section 3: Invoice / Receipt Metadata -->
          <section class="p-5 sm:p-6 space-y-4">
            <div class="flex items-center gap-2">
              <i data-lucide="hash" class="w-4 h-4 text-blue-600 dark:text-blue-400"></i>
              <h2 class="font-display text-base font-bold text-slate-900 dark:text-white">
                ${isInvoice ? 'Invoice Details' : 'Receipt Details'}
              </h2>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label for="doc-number" class="${labelClass}">${isInvoice ? 'Invoice No.' : 'Receipt No.'}</label>
                <input id="doc-number" type="text" data-field="number" value="${escapeHtml(doc.number)}" class="${inputClass} font-mono" />
              </div>
              <div>
                <label for="doc-date" class="${labelClass}">Issue Date</label>
                <input id="doc-date" type="date" data-field="date" value="${escapeHtml(doc.date)}" class="${inputClass} tabular-nums" />
              </div>
              ${
                isInvoice
                  ? `
                <div>
                  <label for="doc-due-date" class="${labelClass}">Due Date</label>
                  <input id="doc-due-date" type="date" data-field="dueDate" value="${escapeHtml(doc.dueDate)}" class="${inputClass} tabular-nums" />
                </div>
              `
                  : ''
              }
              <div>
                <label for="doc-currency" class="${labelClass}">Currency</label>
                <select id="doc-currency" data-field="currency" class="${inputClass}">
                  ${Object.values(CURRENCIES)
                    .map(
                      (c) =>
                        `<option value="${c.code}" ${doc.currency === c.code ? 'selected' : ''}>${escapeHtml(c.label)}</option>`
                    )
                    .join('')}
                </select>
              </div>
            </div>
          </section>

          <!-- Section 4: Line Items Table -->
          <section class="p-5 sm:p-6 space-y-4">
            <div class="flex items-center justify-between gap-4">
              <h2 class="font-display text-base font-bold text-slate-900 dark:text-white">Line Items</h2>
              <button
                type="button"
                data-action="add-item"
                class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-blue-50 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/70 transition-colors cursor-pointer whitespace-nowrap min-h-[38px]"
              >
                <i data-lucide="plus" class="w-4 h-4"></i>
                <span>Add Item</span>
              </button>
            </div>

            <!-- Desktop Column Headers -->
            <div class="hidden sm:grid sm:grid-cols-12 gap-3 text-xs font-semibold text-slate-500 dark:text-slate-400 px-1">
              <div class="col-span-5">Description</div>
              <div class="col-span-2 text-right">Qty</div>
              <div class="col-span-2 text-right">Unit Price</div>
              <div class="col-span-2 text-right">Amount</div>
              <div class="col-span-1"></div>
            </div>

            <div id="items-list" class="space-y-3">
              ${totals.items
                .map(
                  (item, idx) => `
                <div class="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center pb-3 sm:pb-0 border-b sm:border-b-0 border-slate-100 dark:border-slate-800 last:border-b-0" data-item-row="${item.id}">
                  <div class="sm:col-span-5">
                    <label class="sm:hidden ${labelClass}">Description</label>
                    <input
                      type="text"
                      data-item-id="${item.id}"
                      data-item-field="description"
                      value="${escapeHtml(item.description)}"
                      placeholder="Service or product description"
                      class="${inputClass}"
                    />
                  </div>
                  <div class="grid grid-cols-2 sm:contents gap-3">
                    <div class="sm:col-span-2">
                      <label class="sm:hidden ${labelClass}">Quantity</label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        data-item-id="${item.id}"
                        data-item-field="quantity"
                        value="${item.quantity}"
                        class="${inputClass} text-right font-mono tabular-nums"
                      />
                    </div>
                    <div class="sm:col-span-2">
                      <label class="sm:hidden ${labelClass}">Unit Price</label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        data-item-id="${item.id}"
                        data-item-field="unitPrice"
                        value="${item.unitPrice}"
                        class="${inputClass} text-right font-mono tabular-nums"
                      />
                    </div>
                  </div>
                  <div class="flex items-center justify-between sm:contents">
                    <div class="sm:col-span-2 sm:text-right">
                      <span class="sm:hidden text-xs text-slate-500 dark:text-slate-400 mr-2">Amount:</span>
                      <span data-item-amount="${item.id}" class="font-mono text-sm font-semibold text-slate-900 dark:text-white tabular-nums">
                        ${formatCurrency(item.amount, doc.currency)}
                      </span>
                    </div>
                    <div class="sm:col-span-1 flex justify-end">
                      <button
                        type="button"
                        data-remove-item="${item.id}"
                        aria-label="Remove item ${idx + 1}"
                        class="p-2.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-slate-800 transition-colors cursor-pointer min-h-[40px] min-w-[40px] flex items-center justify-center"
                      >
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                      </button>
                    </div>
                  </div>
                </div>
              `
                )
                .join('')}
            </div>
          </section>

          <!-- Section 5: Notes & Payment Terms -->
          <section class="p-5 sm:p-6 space-y-3">
            <label for="doc-notes" class="block font-display text-base font-bold text-slate-900 dark:text-white">
              ${isInvoice ? 'Notes &amp; Payment Terms' : 'Receipt Notes'}
            </label>
            <textarea
              id="doc-notes"
              rows="3"
              data-field="notes"
              placeholder="Bank transfer details, payment instructions, or a thank-you note..."
              class="${inputClass} min-h-[88px] resize-y"
            >${escapeHtml(doc.notes)}</textarea>
          </section>
        </div>

        <!-- Right Column: Calculations, Template Selector & Actions -->
        <aside class="lg:col-span-4 space-y-5 lg:sticky lg:top-6">
          <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 space-y-5">
            <h2 class="font-display text-base font-bold text-slate-900 dark:text-white">Calculations</h2>

            <!-- Tax & Discount Inputs -->
            <div class="space-y-4">
              <div>
                <label for="doc-tax" class="${labelClass}">Tax / VAT (%)</label>
                <input
                  id="doc-tax"
                  type="number"
                  min="0"
                  max="100"
                  step="any"
                  data-field="taxRate"
                  value="${totals.taxRate}"
                  class="${inputClass} font-mono tabular-nums"
                />
              </div>

              <div>
                <div class="flex items-center justify-between mb-1.5">
                  <label for="doc-discount" class="text-xs font-medium text-slate-600 dark:text-slate-300">Discount (Optional)</label>
                  <div class="inline-flex rounded-md border border-slate-200 dark:border-slate-700 overflow-hidden text-xs">
                    <button
                      type="button"
                      data-discount-type="fixed"
                      class="px-2 py-0.5 font-medium cursor-pointer ${
                        totals.discountType === 'fixed'
                          ? 'bg-blue-600 text-white'
                          : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }"
                    >
                      ${CURRENCIES[doc.currency]?.symbol || '₦'}
                    </button>
                    <button
                      type="button"
                      data-discount-type="percent"
                      class="px-2 py-0.5 font-medium cursor-pointer ${
                        totals.discountType === 'percent'
                          ? 'bg-blue-600 text-white'
                          : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }"
                    >
                      %
                    </button>
                  </div>
                </div>
                <input
                  id="doc-discount"
                  type="number"
                  min="0"
                  step="any"
                  data-field="discountValue"
                  value="${totals.discountValue}"
                  class="${inputClass} font-mono tabular-nums"
                />
              </div>
            </div>

            <!-- Live Totals Summary -->
            <div class="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2.5 text-sm">
              <div class="flex items-center justify-between text-slate-600 dark:text-slate-300">
                <span>Subtotal</span>
                <span id="calc-subtotal" class="font-mono font-medium text-slate-900 dark:text-white tabular-nums">
                  ${formatCurrency(totals.subtotal, doc.currency)}
                </span>
              </div>
              <div class="flex items-center justify-between text-slate-600 dark:text-slate-300">
                <span id="calc-tax-label">Tax / VAT (${totals.taxRate}%)</span>
                <span id="calc-tax" class="font-mono font-medium text-slate-900 dark:text-white tabular-nums">
                  ${formatCurrency(totals.taxAmount, doc.currency)}
                </span>
              </div>
              <div class="flex items-center justify-between text-slate-600 dark:text-slate-300">
                <span>Discount</span>
                <span id="calc-discount" class="font-mono font-medium text-red-600 dark:text-red-400 tabular-nums">
                  -${formatCurrency(totals.discountAmount, doc.currency)}
                </span>
              </div>
              <div class="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <span class="font-display text-base font-bold text-slate-900 dark:text-white">
                  ${isInvoice ? 'Total Due' : 'Total Paid'}
                </span>
                <span id="calc-total" class="font-mono text-xl font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                  ${formatCurrency(totals.total, doc.currency)}
                </span>
              </div>
            </div>

            <!-- Template Selector -->
            <div class="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2">
              <span class="block text-xs font-medium text-slate-600 dark:text-slate-300">Template Style</span>
              <div class="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  data-set-template="modern"
                  class="px-3 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer min-h-[40px] ${
                    doc.template === 'modern'
                      ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                      : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }"
                >
                  Modern Blue
                </button>
                <button
                  type="button"
                  data-set-template="classic"
                  class="px-3 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer min-h-[40px] ${
                    doc.template === 'classic'
                      ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                      : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }"
                >
                  Classic Formal
                </button>
              </div>
            </div>

            <!-- Primary & Secondary Action Buttons -->
            <div class="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
              <button
                type="button"
                data-action="open-preview"
                class="w-full inline-flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors cursor-pointer min-h-[44px]"
              >
                <i data-lucide="eye" class="w-4 h-4"></i>
                <span>Preview Document</span>
              </button>

              <div class="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  data-action="save-draft"
                  class="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs sm:text-sm font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer min-h-[42px]"
                >
                  <i data-lucide="save" class="w-4 h-4"></i>
                  <span>Save</span>
                </button>

                <button
                  type="button"
                  data-action="print-draft"
                  class="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs sm:text-sm font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer min-h-[42px]"
                >
                  <i data-lucide="printer" class="w-4 h-4"></i>
                  <span>Print</span>
                </button>
              </div>

              <button
                type="button"
                data-pdf-trigger
                data-action="download-draft-pdf"
                class="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer min-h-[42px]"
              >
                <i data-lucide="download" class="w-4 h-4"></i>
                <span data-pdf-label>Download PDF</span>
              </button>
            </div>
          </div>
        </aside>
      </div>
    </main>
  `;
}

/* -------------------------------------------------------------------------- */
/* 3. Preview Mode                                                            */
/* -------------------------------------------------------------------------- */

function renderPreview() {
  const doc = state.draft;
  const isInvoice = doc.type === 'invoice';

  return `
    <main class="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
      <!-- Preview Toolbar -->
      <div class="no-print bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div class="flex flex-wrap items-center gap-3">
          <button
            type="button"
            data-action="back-to-editor"
            class="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer whitespace-nowrap min-h-[40px]"
          >
            <i data-lucide="arrow-left" class="w-4 h-4"></i>
            <span>Edit Details</span>
          </button>

          <!-- Template Switcher -->
          <div class="inline-flex items-center p-1 rounded-lg bg-slate-100 dark:bg-slate-800">
            <button
              type="button"
              data-preview-template="modern"
              class="px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                doc.template === 'modern'
                  ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }"
            >
              Modern
            </button>
            <button
              type="button"
              data-preview-template="classic"
              class="px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                doc.template === 'classic'
                  ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }"
            >
              Classic
            </button>
          </div>

          ${
            isInvoice
              ? `
            <button
              type="button"
              data-action="toggle-draft-paid"
              class="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap min-h-[40px] ${
                doc.status === 'paid'
                  ? 'border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                  : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700'
              }"
            >
              <i data-lucide="check-circle-2" class="w-4 h-4"></i>
              <span>${doc.status === 'paid' ? 'Paid (Click to Undo)' : 'Mark as Paid'}</span>
            </button>
          `
              : ''
          }
        </div>

        <div class="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            data-action="save-draft"
            class="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer whitespace-nowrap min-h-[40px]"
          >
            <i data-lucide="save" class="w-4 h-4"></i>
            <span>Save</span>
          </button>

          <button
            type="button"
            data-action="print-preview"
            class="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer whitespace-nowrap min-h-[40px]"
          >
            <i data-lucide="printer" class="w-4 h-4"></i>
            <span>Print</span>
          </button>

          <button
            type="button"
            data-pdf-trigger
            data-action="download-draft-pdf"
            class="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors cursor-pointer whitespace-nowrap min-h-[40px]"
          >
            <i data-lucide="download" class="w-4 h-4"></i>
            <span data-pdf-label>Download PDF</span>
          </button>
        </div>
      </div>

      <!-- Printable Paper Sheet -->
      <div id="print-area-wrapper" class="max-w-[820px] mx-auto rounded-xl overflow-hidden shadow-md border border-slate-200 dark:border-slate-800 bg-white">
        ${renderDocumentPaper(doc, doc.template)}
      </div>
    </main>
  `;
}

/* -------------------------------------------------------------------------- */
/* 4. History Page                                                            */
/* -------------------------------------------------------------------------- */

function getFilteredHistoryDocs() {
  const docs = getDocuments();
  const q = state.historySearch.trim().toLowerCase();

  return docs.filter((doc) => {
    if (state.historyFilter === 'invoice' && doc.type !== 'invoice') return false;
    if (state.historyFilter === 'receipt' && doc.type !== 'receipt') return false;
    if (state.historyFilter === 'paid' && !(doc.type === 'receipt' || doc.status === 'paid')) return false;
    if (state.historyFilter === 'pending' && !(doc.type === 'invoice' && doc.status !== 'paid')) return false;

    if (!q) return true;
    const haystack = [doc.number, doc.client?.name, doc.client?.email, doc.business?.name]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();
    return haystack.includes(q);
  });
}

function renderHistory() {
  const allDocs = getDocuments();
  const filtered = getFilteredHistoryDocs();
  const filters = [
    { id: 'all', label: 'All' },
    { id: 'invoice', label: 'Invoices' },
    { id: 'receipt', label: 'Receipts' },
    { id: 'paid', label: 'Paid' },
    { id: 'pending', label: 'Pending' },
  ];

  return `
    <main class="max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-bold text-slate-900 dark:text-white">History</h1>
          <p class="text-sm text-slate-500 dark:text-slate-400">
            ${allDocs.length} saved ${allDocs.length === 1 ? 'document' : 'documents'} stored in your browser
          </p>
        </div>

        <div class="flex items-center gap-2.5">
          <button
            type="button"
            data-action="new-invoice"
            class="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors whitespace-nowrap cursor-pointer min-h-[40px]"
          >
            <i data-lucide="plus" class="w-4 h-4"></i>
            <span>New Invoice</span>
          </button>
          <button
            type="button"
            data-action="new-receipt"
            class="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors whitespace-nowrap cursor-pointer min-h-[40px]"
          >
            <i data-lucide="receipt" class="w-4 h-4"></i>
            <span>New Receipt</span>
          </button>
        </div>
      </div>

      <!-- Search & Segmented Filters -->
      <section class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div class="p-4 sm:px-6 border-b border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div class="relative flex-1 max-w-md">
            <i data-lucide="search" class="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"></i>
            <input
              id="history-search-input"
              type="search"
              value="${escapeHtml(state.historySearch)}"
              placeholder="Search by number or client name..."
              class="w-full pl-10 pr-4 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 min-h-[40px]"
            />
          </div>

          <div class="inline-flex items-center gap-1 p-1 rounded-lg bg-slate-100 dark:bg-slate-800 overflow-x-auto">
            ${filters
              .map(
                (f) => `
              <button
                type="button"
                data-history-filter="${f.id}"
                class="px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  state.historyFilter === f.id
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }"
              >
                ${f.label}
              </button>
            `
              )
              .join('')}
          </div>
        </div>

        <div id="history-results-container">
          ${renderHistoryResults(allDocs, filtered)}
        </div>
      </section>
    </main>
  `;
}

function renderHistoryResults(allDocs, filtered) {
  if (allDocs.length === 0) {
    return renderEmptyState(
      'Your history is empty',
      'Saved invoices and receipts appear here so you can edit, mark paid, print, or download them again anytime.'
    );
  }
  if (filtered.length === 0) {
    return `
      <div class="px-6 py-12 text-center">
        <p class="font-display text-base font-semibold text-slate-900 dark:text-white">No matching documents</p>
        <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">Try clearing your search query or switching filter tabs.</p>
      </div>
    `;
  }
  return renderDocumentTable(filtered);
}

/* -------------------------------------------------------------------------- */
/* Confirmation Modal (Delete Document)                                       */
/* -------------------------------------------------------------------------- */

function renderDeleteModal() {
  if (!state.deleteModalDocId) return '';
  const target = getDocumentById(state.deleteModalDocId);
  const label = target ? `${target.number || target.type}` : 'this document';

  return `
    <div
      id="delete-modal-backdrop"
      role="dialog"
      aria-modal="true"
      aria-labelledby="delete-modal-title"
      class="no-print fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-[2px] flex items-center justify-center p-4"
    >
      <div class="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
        <h3 id="delete-modal-title" class="font-display text-lg font-bold text-slate-900 dark:text-white">
          Delete ${escapeHtml(label)}?
        </h3>
        <p class="text-sm text-slate-600 dark:text-slate-300">
          This will permanently remove the saved record from this browser's local storage. This action cannot be undone.
        </p>
        <div class="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            data-action="cancel-delete"
            class="px-4 py-2 text-sm font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer min-h-[40px]"
          >
            Cancel
          </button>
          <button
            type="button"
            data-action="confirm-delete"
            class="px-4 py-2 text-sm font-semibold rounded-lg bg-red-600 hover:bg-red-700 text-white cursor-pointer min-h-[40px]"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  `;
}

/* -------------------------------------------------------------------------- */
/* Footer                                                                     */
/* -------------------------------------------------------------------------- */

function renderFooter() {
  return `
    <footer class="no-print max-w-6xl mx-auto px-4 sm:px-6 py-8 mt-4 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400">
      <p>QuickInvoice · Stored privately in your browser via localStorage</p>
      <p>Supports NGN (₦), USD ($), EUR (€), and GBP (£)</p>
    </footer>
  `;
}

/* -------------------------------------------------------------------------- */
/* Main Render Loop                                                           */
/* -------------------------------------------------------------------------- */

function render() {
  let content = '';
  if (state.view === 'dashboard') content = renderDashboard();
  else if (state.view === 'editor') content = renderEditor();
  else if (state.view === 'preview') content = renderPreview();
  else if (state.view === 'history') content = renderHistory();

  appRoot.innerHTML = `
    <div class="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      ${renderHeader()}
      <div class="flex-1">
        ${content}
      </div>
      ${renderFooter()}
      ${renderDeleteModal()}
    </div>
  `;

  refreshIcons();
}

/* -------------------------------------------------------------------------- */
/* Live Input Handlers (Preserves Focus While Updating Calculations)          */
/* -------------------------------------------------------------------------- */

function updateCalculatedDomValues() {
  const totals = calculateDocumentTotals(state.draft);
  const curr = state.draft.currency;

  totals.items.forEach((item) => {
    const el = document.querySelector(`[data-item-amount="${item.id}"]`);
    if (el) el.textContent = formatCurrency(item.amount, curr);
  });

  const subtotalEl = document.getElementById('calc-subtotal');
  const taxLabelEl = document.getElementById('calc-tax-label');
  const taxEl = document.getElementById('calc-tax');
  const discountEl = document.getElementById('calc-discount');
  const totalEl = document.getElementById('calc-total');

  if (subtotalEl) subtotalEl.textContent = formatCurrency(totals.subtotal, curr);
  if (taxLabelEl) taxLabelEl.textContent = `Tax / VAT (${totals.taxRate}%)`;
  if (taxEl) taxEl.textContent = formatCurrency(totals.taxAmount, curr);
  if (discountEl) discountEl.textContent = `-${formatCurrency(totals.discountAmount, curr)}`;
  if (totalEl) totalEl.textContent = formatCurrency(totals.total, curr);
}

function setNestedField(obj, path, value) {
  const keys = path.split('.');
  let current = obj;
  for (let i = 0; i < keys.length - 1; i += 1) {
    current = current[keys[i]];
  }
  current[keys[keys.length - 1]] = value;
}

appRoot.addEventListener('input', (event) => {
  const target = event.target;

  // Live History Search without losing input focus
  if (target.id === 'history-search-input') {
    state.historySearch = target.value;
    const container = document.getElementById('history-results-container');
    if (container) {
      container.innerHTML = renderHistoryResults(getDocuments(), getFilteredHistoryDocs());
      refreshIcons();
    }
    return;
  }

  // Editor top-level or nested field
  if (target.dataset.field) {
    const field = target.dataset.field;
    const val = target.type === 'number' ? Number(target.value || 0) : target.value;
    setNestedField(state.draft, field, val);

    if (field.startsWith('business.')) {
      saveBusinessProfile(state.draft.business);
    }
    updateCalculatedDomValues();
    return;
  }

  // Line item field
  if (target.dataset.itemId && target.dataset.itemField) {
    const item = state.draft.items.find((i) => i.id === target.dataset.itemId);
    if (!item) return;
    const fieldName = target.dataset.itemField;
    item[fieldName] = target.type === 'number' ? Number(target.value || 0) : target.value;
    updateCalculatedDomValues();
  }
});

appRoot.addEventListener('change', (event) => {
  const target = event.target;

  // Currency selector change refreshes all formatted symbols
  if (target.dataset.field === 'currency') {
    state.draft.currency = target.value;
    updateCalculatedDomValues();
    return;
  }

  // Logo file upload
  if (target.id === 'logo-file-input' && target.files && target.files[0]) {
    const file = target.files[0];
    if (file.size > 2 * 1024 * 1024) {
      showToast('Please choose a logo image under 2 MB.', 'error');
      target.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      state.draft.business.logo = String(reader.result || '');
      saveBusinessProfile(state.draft.business);
      render();
      showToast('Business logo added.');
    };
    reader.readAsDataURL(file);
  }
});

/* -------------------------------------------------------------------------- */
/* Click Event Delegation                                                     */
/* -------------------------------------------------------------------------- */

appRoot.addEventListener('click', (event) => {
  const btn = event.target.closest('button, [data-action]');
  if (!btn) {
    if (event.target.id === 'delete-modal-backdrop') {
      state.deleteModalDocId = null;
      render();
    }
    return;
  }

  // Header & Mobile Navigation
  if (btn.dataset.nav) {
    const navTarget = btn.dataset.nav;
    if (navTarget === 'new-invoice') startNewDocument('invoice');
    else if (navTarget === 'new-receipt') startNewDocument('receipt');
    else navigateTo(navTarget);
    return;
  }

  // Switch Invoice <-> Receipt inside New Editor
  if (btn.dataset.switchType) {
    const nextType = btn.dataset.switchType;
    if (state.draft.type === nextType) return;
    const isInvoice = nextType === 'invoice';
    state.draft.type = nextType;
    state.draft.status = isInvoice ? 'pending' : 'paid';
    state.draft.dueDate = isInvoice ? state.draft.dueDate || getOffsetDateISO(14) : '';
    state.draft.number = generateDocumentNumber(nextType);
    if (
      state.draft.notes === 'Payment is due within 14 days. Thank you for your business.' ||
      state.draft.notes === 'Payment received with thanks. This serves as your official receipt.'
    ) {
      state.draft.notes = isInvoice
        ? 'Payment is due within 14 days. Thank you for your business.'
        : 'Payment received with thanks. This serves as your official receipt.';
    }
    render();
    return;
  }

  // Discount Type Toggle (Fixed vs %)
  if (btn.dataset.discountType) {
    state.draft.discountType = btn.dataset.discountType;
    render();
    return;
  }

  // Editor Template Selection
  if (btn.dataset.setTemplate) {
    state.draft.template = btn.dataset.setTemplate;
    render();
    return;
  }

  // Preview Template Switcher
  if (btn.dataset.previewTemplate) {
    state.draft.template = btn.dataset.previewTemplate;
    if (state.isEditingExisting) {
      saveDocument(state.draft);
    }
    render();
    return;
  }

  // Remove Line Item
  if (btn.dataset.removeItem) {
    if (state.draft.items.length <= 1) {
      state.draft.items[0] = {
        id: generateId('item'),
        description: '',
        quantity: 1,
        unitPrice: 0,
      };
    } else {
      state.draft.items = state.draft.items.filter((i) => i.id !== btn.dataset.removeItem);
    }
    render();
    return;
  }

  // History Segmented Filter
  if (btn.dataset.historyFilter) {
    state.historyFilter = btn.dataset.historyFilter;
    render();
    return;
  }

  // Table Row Document Actions
  if (btn.dataset.docPreview) {
    previewSavedDocument(btn.dataset.docPreview);
    return;
  }
  if (btn.dataset.docEdit) {
    editSavedDocument(btn.dataset.docEdit);
    return;
  }
  if (btn.dataset.docDownload) {
    const doc = getDocumentById(btn.dataset.docDownload);
    if (doc) handleDownloadPdf(doc);
    return;
  }
  if (btn.dataset.docTogglePaid) {
    const updated = toggleInvoicePaidStatus(btn.dataset.docTogglePaid);
    if (updated) {
      showToast(updated.status === 'paid' ? `${updated.number} marked as Paid.` : `${updated.number} marked as Pending.`);
      render();
    }
    return;
  }
  if (btn.dataset.docDelete) {
    state.deleteModalDocId = btn.dataset.docDelete;
    render();
    return;
  }

  // Named Actions
  const action = btn.dataset.action;
  if (!action) return;

  switch (action) {
    case 'go-dashboard':
      navigateTo('dashboard');
      break;
    case 'go-back':
      navigateTo(state.previousView === 'history' ? 'history' : 'dashboard');
      break;
    case 'toggle-theme':
      toggleDarkMode();
      break;
    case 'new-invoice':
      startNewDocument('invoice');
      break;
    case 'new-receipt':
      startNewDocument('receipt');
      break;
    case 'remove-logo':
      state.draft.business.logo = '';
      saveBusinessProfile(state.draft.business);
      render();
      break;
    case 'add-item':
      state.draft.items.push({
        id: generateId('item'),
        description: '',
        quantity: 1,
        unitPrice: 0,
      });
      render();
      break;
    case 'save-draft':
      saveCurrentDraft(true);
      render();
      break;
    case 'open-preview':
      navigateTo('preview');
      break;
    case 'back-to-editor':
      navigateTo('editor');
      break;
    case 'toggle-draft-paid':
      if (state.draft.type === 'invoice') {
        state.draft.status = state.draft.status === 'paid' ? 'pending' : 'paid';
        if (state.isEditingExisting) {
          saveDocument(state.draft);
        }
        showToast(state.draft.status === 'paid' ? 'Marked as Paid.' : 'Marked as Pending.');
        render();
      }
      break;
    case 'print-draft':
      // Switch to preview briefly or print directly via preview wrapper
      state.view = 'preview';
      render();
      setTimeout(() => window.print(), 120);
      break;
    case 'print-preview':
      window.print();
      break;
    case 'download-draft-pdf':
      handleDownloadPdf(state.draft);
      break;
    case 'cancel-delete':
      state.deleteModalDocId = null;
      render();
      break;
    case 'confirm-delete':
      if (state.deleteModalDocId) {
        deleteDocument(state.deleteModalDocId);
        state.deleteModalDocId = null;
        showToast('Document deleted.');
        render();
      }
      break;
    default:
      break;
  }
});

// Close confirmation modal on Escape key
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && state.deleteModalDocId) {
    state.deleteModalDocId = null;
    render();
  }
});

// Initialize Application
syncThemeOnInit();
render();
