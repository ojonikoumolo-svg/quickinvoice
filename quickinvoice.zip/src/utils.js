/**
 * Utility helpers for QuickInvoice
 * Handles currency formatting, invoice/receipt math, date helpers, and XSS-safe HTML escaping.
 */

export const CURRENCIES = {
  NGN: { code: 'NGN', symbol: '₦', label: '₦ Naira (NGN)' },
  USD: { code: 'USD', symbol: '$', label: '$ US Dollar (USD)' },
  EUR: { code: 'EUR', symbol: '€', label: '€ Euro (EUR)' },
  GBP: { code: 'GBP', symbol: '£', label: '£ British Pound (GBP)' },
};

/**
 * Escapes HTML special characters to safely inject user data into template strings.
 */
export function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Formats a numeric value using the selected currency symbol and two decimal places.
 */
export function formatCurrency(amount, currencyCode = 'NGN') {
  const currency = CURRENCIES[currencyCode] || CURRENCIES.NGN;
  const num = Number(amount);
  const safeNum = Number.isFinite(num) ? num : 0;
  const formatted = Math.abs(safeNum).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return safeNum < 0 ? `-${currency.symbol}${formatted}` : `${currency.symbol}${formatted}`;
}

/**
 * Returns today's date in YYYY-MM-DD local format.
 */
export function getTodayISO() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Returns a date offset by `days` from today in YYYY-MM-DD format.
 */
export function getOffsetDateISO(days = 14) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Formats YYYY-MM-DD into a clean readable date (e.g., "Nov 20, 2026").
 */
export function formatDateDisplay(isoDate) {
  if (!isoDate) return '—';
  const parts = isoDate.split('-').map(Number);
  if (parts.length !== 3 || parts.some(Number.isNaN)) return escapeHtml(isoDate);
  const date = new Date(parts[0], parts[1] - 1, parts[2]);
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

/**
 * Computes item line amounts, subtotal, tax, discount, and grand total.
 */
export function calculateDocumentTotals(doc) {
  const items = Array.isArray(doc?.items) ? doc.items : [];
  let subtotal = 0;

  const computedItems = items.map((item) => {
    const qty = Math.max(0, Number(item.quantity) || 0);
    const unitPrice = Math.max(0, Number(item.unitPrice) || 0);
    const amount = qty * unitPrice;
    subtotal += amount;
    return {
      ...item,
      quantity: qty,
      unitPrice,
      amount,
    };
  });

  const taxRate = Math.max(0, Number(doc?.taxRate) || 0);
  const taxAmount = subtotal * (taxRate / 100);

  const rawDiscount = Math.max(0, Number(doc?.discountValue) || 0);
  const discountType = doc?.discountType === 'percent' ? 'percent' : 'fixed';
  const discountAmount =
    discountType === 'percent'
      ? subtotal * (Math.min(100, rawDiscount) / 100)
      : rawDiscount;

  const total = Math.max(0, subtotal + taxAmount - discountAmount);

  return {
    items: computedItems,
    subtotal,
    taxRate,
    taxAmount,
    discountValue: rawDiscount,
    discountType,
    discountAmount,
    total,
  };
}

/**
 * Checks if an unpaid invoice is past its due date.
 */
export function isInvoiceOverdue(doc) {
  if (!doc || doc.type !== 'invoice' || doc.status === 'paid' || !doc.dueDate) {
    return false;
  }
  return doc.dueDate < getTodayISO();
}

/**
 * Generates a unique client-side ID for saved records and line items.
 */
export function generateId(prefix = 'doc') {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `${prefix}_${crypto.randomUUID()}`;
  }
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}
