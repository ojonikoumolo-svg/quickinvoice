/**
 * localStorage Persistence Layer for QuickInvoice
 * Saves and retrieves invoices, receipts, business defaults, and theme preference.
 */

import { generateId, getOffsetDateISO, getTodayISO } from './utils.js';

const STORAGE_KEYS = {
  DOCUMENTS: 'quickinvoice_documents',
  BUSINESS_PROFILE: 'quickinvoice_business_profile',
  THEME: 'quickinvoice_theme',
};

/**
 * Reads all saved invoices and receipts sorted newest-first.
 */
export function getDocuments() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DOCUMENTS);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.sort((a, b) => (b.updatedAt || b.createdAt || '').localeCompare(a.updatedAt || a.createdAt || ''));
  } catch (err) {
    console.error('Failed to read documents from localStorage:', err);
    return [];
  }
}

/**
 * Writes the full documents array to localStorage.
 */
function persistDocuments(docs) {
  localStorage.setItem(STORAGE_KEYS.DOCUMENTS, JSON.stringify(docs));
}

/**
 * Retrieves a single document by ID.
 */
export function getDocumentById(id) {
  const docs = getDocuments();
  return docs.find((d) => d.id === id) || null;
}

/**
 * Creates or updates a document in localStorage and remembers the business profile.
 */
export function saveDocument(doc) {
  const docs = getDocuments();
  const now = new Date().toISOString();
  const existingIndex = docs.findIndex((d) => d.id === doc.id);

  const recordToSave = {
    ...doc,
    updatedAt: now,
    createdAt: doc.createdAt || now,
  };

  if (existingIndex >= 0) {
    docs[existingIndex] = recordToSave;
  } else {
    docs.unshift(recordToSave);
  }

  persistDocuments(docs);

  if (recordToSave.business) {
    saveBusinessProfile(recordToSave.business);
  }

  return recordToSave;
}

/**
 * Deletes a document by ID from localStorage.
 */
export function deleteDocument(id) {
  const docs = getDocuments().filter((d) => d.id !== id);
  persistDocuments(docs);
  return docs;
}

/**
 * Toggles an invoice's paid/pending status and saves the update.
 */
export function toggleInvoicePaidStatus(id) {
  const docs = getDocuments();
  const index = docs.findIndex((d) => d.id === id);
  if (index < 0) return null;

  const target = docs[index];
  if (target.type !== 'invoice') return target;

  target.status = target.status === 'paid' ? 'pending' : 'paid';
  target.updatedAt = new Date().toISOString();
  docs[index] = target;
  persistDocuments(docs);
  return target;
}

/**
 * Reads the saved business profile so users don't have to re-enter details every time.
 */
export function getBusinessProfile() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BUSINESS_PROFILE);
    if (!raw) {
      return {
        name: '',
        logo: '',
        address: '',
        phone: '',
        email: '',
        website: '',
      };
    }
    const parsed = JSON.parse(raw);
    return {
      name: parsed.name || '',
      logo: parsed.logo || '',
      address: parsed.address || '',
      phone: parsed.phone || '',
      email: parsed.email || '',
      website: parsed.website || '',
    };
  } catch {
    return {
      name: '',
      logo: '',
      address: '',
      phone: '',
      email: '',
      website: '',
    };
  }
}

/**
 * Persists business details for future invoices/receipts.
 */
export function saveBusinessProfile(profile) {
  try {
    localStorage.setItem(STORAGE_KEYS.BUSINESS_PROFILE, JSON.stringify(profile));
  } catch (err) {
    console.warn('Could not persist business profile (storage may be full):', err);
  }
}

/**
 * Auto-generates the next sequential Invoice or Receipt number (e.g., INV-2026-001).
 */
export function generateDocumentNumber(type = 'invoice') {
  const prefix = type === 'receipt' ? 'REC' : 'INV';
  const year = new Date().getFullYear();
  const docs = getDocuments().filter((d) => d.type === type);

  let maxNum = 0;
  const pattern = new RegExp(`^${prefix}-${year}-(\\d+)$`, 'i');

  for (const doc of docs) {
    const match = (doc.number || '').match(pattern);
    if (match) {
      const parsed = parseInt(match[1], 10);
      if (parsed > maxNum) maxNum = parsed;
    }
  }

  const nextNum = Math.max(maxNum + 1, docs.length + 1);
  return `${prefix}-${year}-${String(nextNum).padStart(3, '0')}`;
}

/**
 * Constructs a blank Invoice or Receipt pre-filled with the saved business profile.
 */
export function createEmptyDocument(type = 'invoice') {
  const isInvoice = type === 'invoice';
  const business = getBusinessProfile();

  return {
    id: generateId(isInvoice ? 'inv' : 'rec'),
    type: isInvoice ? 'invoice' : 'receipt',
    template: 'modern',
    status: isInvoice ? 'pending' : 'paid',
    number: generateDocumentNumber(type),
    date: getTodayISO(),
    dueDate: isInvoice ? getOffsetDateISO(14) : '',
    currency: 'NGN',
    business: { ...business },
    client: {
      name: '',
      email: '',
      address: '',
      phone: '',
    },
    items: [
      {
        id: generateId('item'),
        description: '',
        quantity: 1,
        unitPrice: 0,
      },
    ],
    taxRate: 0,
    discountValue: 0,
    discountType: 'fixed',
    notes: isInvoice
      ? 'Payment is due within 14 days. Thank you for your business.'
      : 'Payment received with thanks. This serves as your official receipt.',
    createdAt: '',
    updatedAt: '',
  };
}

/**
 * Theme preference helpers.
 */
export function getSavedTheme() {
  try {
    return localStorage.getItem(STORAGE_KEYS.THEME);
  } catch {
    return null;
  }
}

export function saveTheme(theme) {
  try {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  } catch {
    // Ignore storage errors
  }
}
